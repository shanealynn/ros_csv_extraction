#!/usr/bin/env python

import roslib 
roslib.load_manifest('data_extraction')
import rospy
import rosbag
import csv
import sys
import getopt

def usage():
 	print " Usage:"
 	print " gps_extract -r rosbag_file_name -o output_file_name -t IMU_topic_name"
 	print ""
 	print "  rosbag_file_name - path to ros .bag file containing IMU records"
 	print "  output_file_name - path to save records to. CSV format used."
 	print "  IMU_topic_name - topic in bag file that contains GPSFix messages"
 	print "                   of format sensor_msgs/NavSatFix"
 	print "  "
 	print "  IMU Rosbag Extraction Script v1 - Shane Lynn - 3rd May 2012"
 	print ""


def main():
	rospy.loginfo("Processing input arguments:")
	try:
		opts, extraparams = getopt.getopt(sys.argv[1:], "o:b:t:") #start at the second argument.
	except getopt.GetoptError, err:
		#print error info and exit
		print str(err)
		usage()
		sys.exit(2)
	
	#default values
	outFile = "output.csv"
	rosbagFile = "bagfile.bag"
	topic = "/novatel_gps/gpsFix"
	
	for o,a in opts:
		if o == "-o":
			outFile = a
		elif o == "-b":
			rosbagFile = a
		elif o == "-t":
			topic = a
		else:
			assert False, "unhandled option"
			usage()
		
	rospy.loginfo ("Opening bag file: " + rosbagFile)
	bag = rosbag.Bag(rosbagFile)
	rospy.loginfo ("Bag file opened.")

	rospy.loginfo("Opening " + outFile + " for writing..")
	fileH = open(outFile, 'wt')
	fileWriter = csv.writer(fileH)

	rospy.loginfo("Getting topic " + topic + " from bag file...")
	count = 1
	fileWriter.writerow(["Time", "Header sequence", "Header secs", "Header nsecs", \
		                 "Latitude", "Longitude", "Altitude", "Position Covariance"])
	for topic, msg, t in bag.read_messages(topics=topic):        
		count = count + 1
		#print type(msg)	
		fileWriter.writerow([t, msg.header.seq, msg.header.stamp.secs, msg.header.stamp.nsecs, \
		                     msg.latitude, msg.longitude, msg.altitude, msg.position_covariance])    

	rospy.loginfo("Processed %s records." %count)
	if count < 5:
		rospy.logwarn("Very few records processed - is your topic name correct?")
	rospy.loginfo("Closing files....")
	fileH.close()
	bag.close()
	rospy.loginfo("done!")
	
main()
