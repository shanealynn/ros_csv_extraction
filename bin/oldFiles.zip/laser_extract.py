#!/usr/bin/env python

import roslib 
roslib.load_manifest('data_extraction')
import rospy
import rosbag
import csv
import sys
import getopt

def usage():
 	print " Usage:"
 	print " laser_extract.py -r rosbag_file_name -o output_file_name -t laser_topic_name"
 	print ""
 	print "  rosbag_file_name - path to ros .bag file containing IMU records"
 	print "  output_file_name - path to save records to. CSV format used."
 	print "  IMU_topic_name - topic in bag file that contains IMU messages"
 	print "                   of format sensor_msgs/laserScan"
 	print "  "
 	print "  LaserScan Rosbag Extraction Script v1 - Shane Lynn - 3rd May 2012"
 	print ""


def main():
	rospy.loginfo("Processing input arguments:")
	try:
		opts, extraparams = getopt.getopt(sys.argv[1:], "o:b:t:") #start at the second argument.
	except getopt.GetoptError, err:
		#print error info and exit
		print str(err)
		usage()
		sys.exit(2)
	
	#default values
	outFile = "output.csv"
	rosbagFile = "bagfile.bag"
	imuTopic = "/crossbow_imu/data"
	
	for o,a in opts:
		if o == "-o":
			outFile = a
		elif o == "-b":
			rosbagFile = a
		elif o == "-t":
			imuTopic = a
		else:
			assert False, "unhandled option"
			usage()
		
	rospy.loginfo ("Opening bag file: " + rosbagFile)
	bag = rosbag.Bag(rosbagFile)
	rospy.loginfo ("Bag file opened.")

	rospy.loginfo("Opening " + outFile + " for writing..")
	fileH = open(outFile, 'wt')
	fileWriter = csv.writer(fileH)

	rospy.loginfo("Getting topic " + imuTopic + " from bag file...")
	count = 1
	headerRow = ["Time", "Header sequence", "Header secs", "Header nsecs", \
						 "angle_min", "angle_max", "angle_increment","time_increment", "scan_time", "range_min", "range_max" ]
	
	#fileWriter.writerow(["Time", "Header sequence", "Header secs", "Header nsecs", \
	#"angle_min", "angle_max", "angle_increment","time_increment", "scan_time", "range_min", "range_max",\
	#						 "ranges", "intensities" ])
	for topic, msg, t in bag.read_messages(topics=imuTopic):        
		if count == 1:
			#set up the header row:
			for i in range(len(msg.ranges)):
				headerRow.append("Range%s"%(i+1))
			if len(msg.intensities) >= 1:
				for i in range(len(msg.intensities)):
					headerRow.append("Intensity%s"%(i+1))
			fileWriter.writerow(headerRow)
			
		count = count + 1
		
		#should handle the radar ranges in a column each.
		columns = [t, msg.header.seq, msg.header.stamp.secs, msg.header.stamp.nsecs, \
		                     msg.angle_min, msg.angle_max, msg.angle_increment, msg.time_increment, msg.scan_time, msg.range_min, msg.range_max ]
		for i in range(len(msg.ranges)): 
			columns.append(msg.ranges[i])
		
		if len(msg.intensities) >= 1:
			for i in range(len(msg.intensities)): 
				columns.append(msg.intensities[i])
		#write the columns to the file.
		fileWriter.writerow(columns)
								    
	#Summarise for user								    
	rospy.loginfo("Processed %s records." %count)
	if count < 5:
		rospy.logwarn("Very few records processed - is your topic name correct?")
	rospy.loginfo("Closing files....")
	fileH.close()
	bag.close()
	rospy.loginfo("done!")
	
main()
