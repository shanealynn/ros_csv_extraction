#!/usr/bin/env python

import roslib 
roslib.load_manifest('data_extraction')
import rospy
import rosbag
import csv
import sys
import getopt

def usage():
 	print " Usage:"
 	print " imu_extract -r rosbag_file_name -o output_file_name -t IMU_topic_name"
 	print ""
 	print "  rosbag_file_name - path to ros .bag file containing IMU records"
 	print "  output_file_name - path to save records to. CSV format used."
 	print "  IMU_topic_name - topic in bag file that contains IMU messages"
 	print "                   of format sensor_msgs/Imu"
 	print "  "
 	print "  IMU Rosbag Extraction Script v1 - Shane Lynn - 3rd May 2012"
 	print ""


def main():
	rospy.loginfo("Processing input arguments:")
	try:
		opts, extraparams = getopt.getopt(sys.argv[1:], "o:b:t:") #start at the second argument.
	except getopt.GetoptError, err:
		#print error info and exit
		print str(err)
		usage()
		sys.exit(2)
	
	#default values
	outFile = "output.csv"
	rosbagFile = "bagfile.bag"
	imuTopic = "/crossbow_imu/data"
	
	for o,a in opts:
		if o == "-o":
			outFile = a
		elif o == "-b":
			rosbagFile = a
		elif o == "-t":
			imuTopic = a
		else:
			assert False, "unhandled option"
			usage()
		
	rospy.loginfo ("Opening bag file: " + rosbagFile)
	bag = rosbag.Bag(rosbagFile)
	rospy.loginfo ("Bag file opened.")

	rospy.loginfo("Opening" + outFile + " for writing..")
	fileH = open(outFile, 'wt')
	fileWriter = csv.writer(fileH)

	rospy.loginfo("Getting topic " + imuTopic + " from bag file...")
	count = 1
	fileWriter.writerow(["Time", "Header sequence", "Header secs", "Header nsecs" \
		                 "Orientation x", "Orientation y", "Orientation z", "Orientation w", \
		                 "Angular Velocity x", "Angular Velocity y", "Angular Velocity z", \
		                 "Linear Acceleration x", "Linear Acceleration y", "Linear Acceleration z"])
	for topic, msg, t in bag.read_messages(topics=imuTopic):        
		count = count + 1
		fileWriter.writerow([t, msg.header.seq, msg.header.stamp.secs, msg.header.stamp.nsecs, \
		                     msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w, \
		                     msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z, \
		                     msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])    

	rospy.loginfo("Processed %s records." %count)
	if count < 5:
		rospy.logwarn("Very few records processed - is your topic name correct?")
	rospy.loginfo("Closing files....")
	fileH.close()
	bag.close()
	rospy.loginfo("done!")
	
main()
